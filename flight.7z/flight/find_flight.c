
find_flight()
{
	char depart_city[50],arrive_city[50],rand_deaprt_city[50],rand_arrive_city[50];

	int deaprt_num=0,arrive_num=0;

	deaprt_num=rand()%(lr_paramarr_len("flight_info")/2)+1;

	if (deaprt_num==10)
	{
		arrive_num=deaprt_num-1;
	}
	else
	{
		arrive_num=deaprt_num+1;
	};

	lr_output_message("deaprt_num's value=%d,arrive_num's value=%d",deaprt_num,arrive_num);

	sprintf(rand_deaprt_city,"{flight_info_%d}",deaprt_num);
	
	sprintf(rand_arrive_city,"{flight_info_%d}",arrive_num);

	sprintf(depart_city, "Value=%s",lr_eval_string(rand_deaprt_city));

	sprintf(arrive_city, "Value=%s",lr_eval_string(rand_arrive_city));

	lr_think_time(10);

	web_reg_save_param("flight_num","LB=name=outboundFlight value=","RB={departdate}","ORD=ALL",LAST);

	web_submit_data("reservations.pl", 
		"Action=http://127.0.0.1:1080/WebTours/reservations.pl", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/WebTours/reservations.pl?page=welcome", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=depart", depart_city, ENDITEM, 
		"Name=departDate", "Value={departdate}", ENDITEM, 
		"Name=arrive", arrive_city, ENDITEM, 
		"Name=returnDate", "Value={returndate}", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		"Name=.cgifields", "Value=roundtrip", ENDITEM, 
		"Name=.cgifields", "Value=seatType", ENDITEM, 
		"Name=.cgifields", "Value=seatPref", ENDITEM, 
		"Name=findFlights.x", "Value=44", ENDITEM, 
		"Name=findFlights.y", "Value=6", ENDITEM, 
		LAST);


	lr_output_message("flight_num�����й���%d��Ԫ��",lr_paramarr_len("flight_num"));


	lr_output_message("flight_num���������ȡֵ�ǣ�%s",lr_paramarr_random("flight_num"));

	return 0;
}
