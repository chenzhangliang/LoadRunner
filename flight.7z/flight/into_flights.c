into_flights()
{

	lr_think_time(5);

	web_reg_save_param("flight_info","LB=\">","RB=</option>","ORD=ALL",LAST);

	web_url("welcome.pl", 
		"URL=http://127.0.0.1:1080/WebTours/welcome.pl?page=search", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/WebTours/nav.pl?page=menu&in=home", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(5);

	web_url("FormDateUpdate.class", 
		"URL=http://127.0.0.1:1080/WebTours/FormDateUpdate.class", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Mode=HTML", 
		LAST);

	web_url("CalSelect.class", 
		"URL=http://127.0.0.1:1080/WebTours/CalSelect.class", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Mode=HTML", 
		LAST);

	web_url("Calendar.class", 
		"URL=http://127.0.0.1:1080/WebTours/Calendar.class", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Mode=HTML", 
		LAST);

	return 0;
}
